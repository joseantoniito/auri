<div class="advance-search header-advance-search">

    <?php get_template_part( 'partials/search/header-form' ); ?>

</div><!-- .advance-search -->