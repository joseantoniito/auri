<?php
/*
 * Display featured image
 */
inspiry_standard_thumbnail();