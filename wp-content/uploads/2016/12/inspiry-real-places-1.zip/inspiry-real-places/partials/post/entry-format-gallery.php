<?php
/*
 * Display standard gallery
 */
inspiry_standard_gallery();