<div class="option-bar property-bathrooms">
    <select name="bathrooms" id="select-bathrooms" class="search-select">
        <?php inspiry_number_options( 'bathrooms', __( 'Min Baths (Any)', 'inspiry' ) ) ?>
    </select>
</div>