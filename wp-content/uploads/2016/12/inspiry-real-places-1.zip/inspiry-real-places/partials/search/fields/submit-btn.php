<div class="option-bar form-control-buttons">
    <input type="submit" value="<?php _e( 'Search', 'inspiry' ); ?>" class="form-submit-btn">
</div>