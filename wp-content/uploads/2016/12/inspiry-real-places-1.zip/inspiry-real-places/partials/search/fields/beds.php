<div class="option-bar property-bedrooms">
    <select name="bedrooms" id="select-bedrooms" class="search-select">
        <?php inspiry_number_options( 'bedrooms', __( 'Min Beds (Any)', 'inspiry' ) ) ?>
    </select>
</div>