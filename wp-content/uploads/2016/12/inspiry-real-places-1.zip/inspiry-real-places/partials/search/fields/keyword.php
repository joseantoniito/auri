<div class="option-bar property-keyword">
    <input type="text" name="keyword" id="keyword-txt" value="<?php echo isset ( $_GET['keyword'] ) ? $_GET['keyword'] : ''; ?>" placeholder="<?php _e('Keyword', 'inspiry'); ?>" />
</div>