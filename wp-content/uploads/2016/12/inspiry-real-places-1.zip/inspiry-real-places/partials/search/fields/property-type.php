<div class="option-bar property-type">
    <select name="type" id="select-property-type" class="search-select">
        <?php inspiry_generate_taxonomy_options( 'property-type', __( 'Property Type', 'inspiry' ) ); ?>
    </select>
</div>