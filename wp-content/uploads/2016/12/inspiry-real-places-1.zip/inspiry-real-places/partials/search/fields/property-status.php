<div class="option-bar property-status">
    <select name="status" id="select-status" class="search-select">
        <?php inspiry_generate_taxonomy_options( 'property-status', __( 'Property Status', 'inspiry' ) ); ?>
    </select>
</div>