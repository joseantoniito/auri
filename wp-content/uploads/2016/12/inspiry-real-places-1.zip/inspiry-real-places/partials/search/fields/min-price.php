
<div class="option-bar property-min-price">
    <select name="min-price" id="select-min-price" class="search-select">
        <?php inspiry_minimum_prices_options(); ?>
    </select>
</div>