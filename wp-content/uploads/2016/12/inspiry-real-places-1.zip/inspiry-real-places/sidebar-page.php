<aside class="sidebar">

    <?php
    if ( is_active_sidebar( 'default-page-sidebar' ) ) {
        dynamic_sidebar ( 'default-page-sidebar' );
    }
    ?>

</aside><!-- .sidebar -->




