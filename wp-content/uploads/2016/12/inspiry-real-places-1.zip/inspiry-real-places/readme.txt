You consult this theme's documentation for detailed instructions.

if you need any help, You can submit a support ticket at our support site http://support.inspirythemes.com/.

For general WordPress issues you can search your issue in Google. As there are thousands of helping articles and forum threads out there to help WordPress users.