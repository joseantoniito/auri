(function( $ ) {
    'use strict';

    $(function() {

        /**
         * Disable parent select
         */
        $( "#newproperty-feature_parent" ).remove();
        $( "#newproperty-status_parent" ).remove();

    });

})( jQuery );