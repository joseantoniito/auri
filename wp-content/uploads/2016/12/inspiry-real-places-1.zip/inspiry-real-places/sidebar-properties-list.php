<aside class="sidebar">

    <?php
    if ( is_active_sidebar( 'properties-list' ) ) {
        dynamic_sidebar ( 'properties-list' );
    }
    ?>

</aside><!-- .sidebar -->

