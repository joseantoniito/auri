
<div class="option-bar col-xs-12 property-max-area">
    <input type="text" name="max-area" id="max-area" pattern="[0-9]+" value="<?php echo isset($_GET['max-area'])?$_GET['max-area']:''; ?>" placeholder="<?php _e('Max Area (sq ft)', 'inspiry'); ?>" title="<?php _e('Please only provide digits!','inspiry'); ?>" />
</div>