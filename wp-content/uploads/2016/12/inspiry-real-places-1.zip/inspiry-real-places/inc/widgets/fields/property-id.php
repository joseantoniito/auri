<div class="option-bar col-xs-12 property-id">
    <input type="text" name="property-id" id="property-id-txt" value="<?php echo isset($_GET['property-id'])?$_GET['property-id']:''; ?>" placeholder="<?php _e('Property ID', 'inspiry'); ?>" />
</div>