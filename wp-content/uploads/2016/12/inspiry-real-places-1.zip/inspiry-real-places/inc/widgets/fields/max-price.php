
<div class="option-bar col-xs-12 property-max-price">
    <select name="max-price" id="select-max-price" class="search-select">
        <?php inspiry_maximum_prices_options(); ?>
    </select>
</div>