
<div class="option-bar col-xs-12 property-min-area">
    <input type="text" name="min-area" id="min-area" pattern="[0-9]+" value="<?php echo isset($_GET['min-area'])?$_GET['min-area']:''; ?>" placeholder="<?php _e('Min Area (sq ft)', 'inspiry'); ?>" title="<?php _e('Please only provide digits!','inspiry'); ?>" />
</div>