<div class="option-bar col-xs-12 submit-btn-wrapper">
    <input type="submit" value="<?php _e( 'Search', 'inspiry' ); ?>" class="form-submit-btn">
</div>