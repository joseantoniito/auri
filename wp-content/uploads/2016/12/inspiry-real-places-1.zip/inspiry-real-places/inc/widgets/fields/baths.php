<div class="option-bar col-xs-12 property-bathrooms">
    <select name="bathrooms" id="select-bathrooms" class="search-select">
        <?php inspiry_number_options( 'bathrooms', __( 'Min Baths (Any)', 'inspiry' ) ) ?>
    </select>
</div>