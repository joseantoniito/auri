<?php
/*
 * Property Status - Custom Taxonomy Archive
 */
get_template_part( 'partials/property/templates/archive' );