<aside class="sidebar">

    <?php
    if ( is_active_sidebar( 'properties-grid' ) ) {
        dynamic_sidebar ( 'properties-grid' );
    }
    ?>

</aside><!-- .sidebar -->

