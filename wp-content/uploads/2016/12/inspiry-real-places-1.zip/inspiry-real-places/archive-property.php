<?php
/*
 * Property Post Type Archive
 */
get_template_part( 'partials/property/templates/archive' );