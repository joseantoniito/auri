<aside class="sidebar">

    <?php
    if ( is_active_sidebar( 'default-sidebar' ) ) {
        dynamic_sidebar( 'default-sidebar' );
    }
    ?>

</aside><!-- .sidebar -->

