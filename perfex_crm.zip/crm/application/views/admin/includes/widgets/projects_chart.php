 <div class="panel_s">
  <div class="panel-body">
   <p class="mbot5"><?php echo _l('home_stats_by_project_status'); ?></p>
   <canvas class="chart" id="projects_status_stats"></canvas>
</div>
</div>
