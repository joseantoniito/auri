<div class="clearfix"></div>
<div class="panel_s">
   <div class="panel-body">
      <div class="dt-loader hide"></div>
      <div id="calendar"></div>
  </div>
</div>
<div class="clearfix"></div>
