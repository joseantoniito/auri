    <div class="panel_s">
      <div class="panel-body">
         <p class="mleft5"><?php echo _l('home_lead_overview'); ?></p>
         <canvas class="chart" id="leads_status_stats"></canvas>
     </div>
 </div>


