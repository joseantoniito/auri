<?php init_head(); ?>
<div id="wrapper">
	<div class="content">
		<div class="row">
			<?php include_once(APPPATH . 'views/admin/includes/alerts.php'); ?>
		</div>
	</div>
</div>
<?php init_tail(); ?>
</body>
</html>
