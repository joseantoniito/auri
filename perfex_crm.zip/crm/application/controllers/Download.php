<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Download extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->helper('download');
    }
    public function preview_image(){
        $path = $this->input->get('path');
        $file_type = $this->input->get('type');
        if(!file_exists($path)){
          $file_type = 'image/jpg';
          $path = FCPATH .'assets/images/preview_no_available.jpg';
        }
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.basename($path).'"');
        header('Content-Type: '.$file_type);
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        echo readfile($path);

    }
    public function file($folder_indicator, $attachmentid = '')
    {
        $this->load->model('tickets_model');
        if ($folder_indicator == 'ticket') {
            if (is_logged_in()) {
                $this->db->where('id', $attachmentid);
                $attachment = $this->db->get('tblticketattachments')->row();
                if (!$attachment) {
                    die('No attachment found in database');
                }
                $ticket   = $this->tickets_model->get_ticket_by_id($attachment->ticketid);
                $ticketid = $attachment->ticketid;
                if ($ticket->userid == get_client_user_id() || is_staff_logged_in()) {
                    if ($attachment->id != $attachmentid) {
                        die('Attachment or ticket not equal');
                    }
                    $path = get_upload_path_by_type('ticket') . $ticketid . '/' . $attachment->file_name;
                    $name = $attachment->file_name;
                }
            }
        } else if ($folder_indicator == 'newsfeed') {
            if (is_logged_in()) {
                if (!$attachmentid) {
                    die('No attachmentid specified');
                }
                $this->db->where('id', $attachmentid);
                $attachment = $this->db->get('tblfiles')->row();
                if (!$attachment) {
                    die('No attachment found in database');
                }
                $path = get_upload_path_by_type('newsfeed') . $attachment->rel_id . '/' . $attachment->file_name;
                $name = $attachment->file_name;
            }
        } else if ($folder_indicator == 'contract') {
            if (is_logged_in()) {
                if (!$attachmentid) {
                    die('No attachmentid specified');
                }
                $this->db->where('id', $attachmentid);
                $attachment = $this->db->get('tblfiles')->row();
                if (!$attachment) {
                    die('No attachment found in database');
                }
                $this->load->model('contracts_model');
                $contract = $this->contracts_model->get($attachment->rel_id);
                if (is_client_logged_in()) {
                    if ($contract->not_visible_to_client == 1) {
                        if (!is_staff_logged_in()) {
                            die;
                        }
                    }
                }
                if (!is_staff_logged_in()) {
                    if ($contract->client != get_client_user_id()) {
                        die();
                    }
                } else {
                    if (!has_permission('contracts','','view')) {
                        access_denied('contracts');
                    }
                }
                $path = get_upload_path_by_type('contract') . $attachment->rel_id . '/' . $attachment->file_name;
                $name = $attachment->file_name;
            }
        } else if ($folder_indicator == 'taskattachment') {
            if (!is_staff_logged_in() && !is_client_logged_in()) {
                die();
            }

            $this->db->where('id', $attachmentid);
            $attachment = $this->db->get('tblfiles')->row();
            if (!$attachment) {
                die('No attachment found in database');
            }
            $path = get_upload_path_by_type('task') . $attachment->rel_id . '/' . $attachment->file_name;
            $name = $attachment->file_name;
        } else if ($folder_indicator == 'sales_attachment') {
            $this->db->where('attachment_key', $attachmentid);
            $attachment = $this->db->get('tblfiles')->row();
            if (!$attachment) {
                die('No attachment found in database');
            }

            $path = get_upload_path_by_type($attachment->rel_type) . $attachment->rel_id . '/' . $attachment->file_name;
            $name = $attachment->file_name;

        } else if ($folder_indicator == 'expense') {
            if (!is_staff_logged_in()) {
                die();
            }
            $this->db->where('rel_id', $attachmentid);
            $this->db->where('rel_type', 'expense');
            $file = $this->db->get('tblfiles')->row();
            $path    = get_upload_path_by_type('expense') . $file->rel_id . '/' . $file->file_name;
            $name    = $file->file_name;
        } else if ($folder_indicator == 'lead_attachment') {
            if (!is_staff_logged_in()) {
                die();
            }
            $this->db->where('id', $attachmentid);
            $attachment = $this->db->get('tblfiles')->row();
            if (!$attachment) {
                die('No attachment found in database');
            }
            $path = get_upload_path_by_type('lead') . $attachment->rel_id . '/' . $attachment->file_name;
            $name = $attachment->file_name;
        } else if ($folder_indicator == 'db_backup') {
            if (!is_admin()) {
                die('Access forbidden');
            }
            $path = BACKUPS_FOLDER . $attachmentid;
            $name = $attachmentid;
        } else if ($folder_indicator == 'client') {
            if(!is_client_logged_in()){
                $this->db->where('id', $attachmentid);
            } else {
                $this->db->where('attachment_key',$attachmentid);
            }
            $attachment = $this->db->get('tblfiles')->row();
            if(!$attachment){die;}
             if (has_permission('customers','','view') || is_customer_admin($attachment->rel_id) || is_client_logged_in()) {
                $path       = get_upload_path_by_type('customer') . $attachment->rel_id . '/' . $attachment->file_name;
                $name       = $attachment->file_name;
             }
        } else {
            die('folder not specified');
        }
        $data = file_get_contents($path);
        force_download($name, $data);
    }
}
