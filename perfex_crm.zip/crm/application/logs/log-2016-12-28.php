<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-28 00:58:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 01:01:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 01:04:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 01:05:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 01:05:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 01:05:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 01:13:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 01:13:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 01:13:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 01:36:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 01:36:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 01:36:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 01:50:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 01:50:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 01:50:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 02:17:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 02:17:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 02:17:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 02:28:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 02:28:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 02:28:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 02:41:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 02:41:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 02:41:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 02:43:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 02:43:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 02:43:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 02:46:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 02:46:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 02:46:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 02:47:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 02:47:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 02:47:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 02:48:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 02:48:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 02:48:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 02:50:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 02:50:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 02:50:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 03:51:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 03:51:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 03:51:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 03:54:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 03:54:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 03:54:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 03:59:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 03:59:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 03:59:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 04:07:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 04:07:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 04:08:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 04:08:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 04:08:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 04:08:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 04:08:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 04:08:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 04:12:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 04:12:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 04:12:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 04:47:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 04:48:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 04:48:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 04:48:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 04:48:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 04:50:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 04:50:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 04:50:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 05:37:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 05:37:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 05:43:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 05:43:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 05:44:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 05:44:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 05:44:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 05:49:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 05:49:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 05:49:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 05:55:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 05:55:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 05:55:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:03:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:03:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 01:04:26 --> Severity: Notice --> Undefined variable: id F:\xampp\htdocs\perfex_crm\crm\application\views\admin\invoice_items\invoice_item.php 35
ERROR - 2016-12-28 08:04:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:04:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:04:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 01:08:04 --> Severity: Notice --> Undefined variable: id F:\xampp\htdocs\perfex_crm\crm\application\views\admin\invoice_items\invoice_item.php 35
ERROR - 2016-12-28 08:08:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:08:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:08:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 01:09:04 --> Severity: Notice --> Undefined variable: id F:\xampp\htdocs\perfex_crm\crm\application\views\admin\invoice_items\invoice_item.php 35
ERROR - 2016-12-28 08:09:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:09:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:09:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:17:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:17:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:17:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:19:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:19:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:19:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:20:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:20:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:20:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:23:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:23:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:23:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:23:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:23:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:23:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:28:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:28:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:28:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:32:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:32:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:32:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:45:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:45:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:45:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:45:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:45:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:45:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 01:57:03 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 08:57:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:57:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:57:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:57:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:57:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:57:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 01:59:25 --> Could not find the language line "status"
ERROR - 2016-12-28 01:59:25 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 01:59:25 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 01:59:25 --> Could not find the language line "banios"
ERROR - 2016-12-28 01:59:25 --> Could not find the language line "precio"
ERROR - 2016-12-28 08:59:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:59:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 08:59:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 02:05:05 --> Could not find the language line "status"
ERROR - 2016-12-28 02:05:05 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 02:05:05 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 02:05:05 --> Could not find the language line "banios"
ERROR - 2016-12-28 02:05:05 --> Could not find the language line "precio"
ERROR - 2016-12-28 02:05:51 --> Could not find the language line "status"
ERROR - 2016-12-28 02:05:51 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 02:05:51 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 02:05:51 --> Could not find the language line "banios"
ERROR - 2016-12-28 02:05:51 --> Could not find the language line "precio"
ERROR - 2016-12-28 02:06:10 --> Could not find the language line "status"
ERROR - 2016-12-28 02:06:10 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 02:06:10 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 02:06:10 --> Could not find the language line "banios"
ERROR - 2016-12-28 02:06:10 --> Could not find the language line "precio"
ERROR - 2016-12-28 02:07:39 --> Could not find the language line "status"
ERROR - 2016-12-28 02:07:39 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 02:07:39 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 02:07:39 --> Could not find the language line "banios"
ERROR - 2016-12-28 02:07:39 --> Could not find the language line "precio"
ERROR - 2016-12-28 09:08:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 09:08:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 02:12:52 --> Could not find the language line "status"
ERROR - 2016-12-28 02:12:52 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 02:12:52 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 02:12:52 --> Could not find the language line "banios"
ERROR - 2016-12-28 02:12:52 --> Could not find the language line "precio"
ERROR - 2016-12-28 02:13:27 --> Could not find the language line "status"
ERROR - 2016-12-28 02:13:27 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 02:13:27 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 02:13:27 --> Could not find the language line "banios"
ERROR - 2016-12-28 02:13:27 --> Could not find the language line "precio"
ERROR - 2016-12-28 02:16:40 --> Could not find the language line "status"
ERROR - 2016-12-28 02:16:40 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 02:16:40 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 02:16:40 --> Could not find the language line "banios"
ERROR - 2016-12-28 02:16:40 --> Could not find the language line "precio"
ERROR - 2016-12-28 02:43:11 --> Severity: error --> Exception: syntax error, unexpected '?', expecting end of file F:\xampp\htdocs\perfex_crm\crm\application\views\admin\invoice_items\invoice_item.php 26
ERROR - 2016-12-28 02:43:45 --> Could not find the language line "status"
ERROR - 2016-12-28 02:43:45 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 02:43:45 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 02:43:45 --> Could not find the language line "banios"
ERROR - 2016-12-28 02:43:45 --> Could not find the language line "precio"
ERROR - 2016-12-28 02:44:11 --> Could not find the language line "status"
ERROR - 2016-12-28 02:44:11 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 02:44:11 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 02:44:11 --> Could not find the language line "banios"
ERROR - 2016-12-28 02:44:11 --> Could not find the language line "precio"
ERROR - 2016-12-28 03:05:20 --> Could not find the language line "description"
ERROR - 2016-12-28 03:05:20 --> Could not find the language line "rate"
ERROR - 2016-12-28 03:05:20 --> Severity: Notice --> Undefined property: stdClass::$recamaras F:\xampp\htdocs\perfex_crm\crm\application\views\admin\invoice_items\invoice_item.php 21
ERROR - 2016-12-28 03:05:20 --> Could not find the language line "long_description"
ERROR - 2016-12-28 03:05:20 --> Could not find the language line "address"
ERROR - 2016-12-28 03:06:22 --> Could not find the language line "description"
ERROR - 2016-12-28 03:06:22 --> Could not find the language line "rate"
ERROR - 2016-12-28 03:06:22 --> Could not find the language line "long_description"
ERROR - 2016-12-28 03:06:22 --> Could not find the language line "address"
ERROR - 2016-12-28 03:07:36 --> Could not find the language line "description"
ERROR - 2016-12-28 03:07:36 --> Could not find the language line "rate"
ERROR - 2016-12-28 03:07:36 --> Could not find the language line "long_description"
ERROR - 2016-12-28 03:07:36 --> Could not find the language line "address"
ERROR - 2016-12-28 03:07:36 --> Could not find the language line "status"
ERROR - 2016-12-28 03:07:36 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 03:07:36 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 03:07:36 --> Could not find the language line "banios"
ERROR - 2016-12-28 03:07:36 --> Could not find the language line "precio"
ERROR - 2016-12-28 10:08:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 10:11:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-28 03:13:52 --> Could not find the language line "description"
ERROR - 2016-12-28 03:13:52 --> Could not find the language line "rate"
ERROR - 2016-12-28 03:13:53 --> Could not find the language line "long_description"
ERROR - 2016-12-28 03:13:53 --> Could not find the language line "address"
ERROR - 2016-12-28 03:13:53 --> Could not find the language line "status"
ERROR - 2016-12-28 03:13:53 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 03:13:53 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 03:13:53 --> Could not find the language line "banios"
ERROR - 2016-12-28 03:13:53 --> Could not find the language line "precio"
ERROR - 2016-12-28 17:15:11 --> Could not find the language line "description"
ERROR - 2016-12-28 17:15:11 --> Could not find the language line "rate"
ERROR - 2016-12-28 17:15:11 --> Could not find the language line "long_description"
ERROR - 2016-12-28 17:15:11 --> Could not find the language line "address"
ERROR - 2016-12-28 17:15:11 --> Could not find the language line "status"
ERROR - 2016-12-28 17:15:11 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 17:15:11 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 17:15:11 --> Could not find the language line "banios"
ERROR - 2016-12-28 17:15:11 --> Could not find the language line "precio"
ERROR - 2016-12-28 17:29:44 --> Could not find the language line "description"
ERROR - 2016-12-28 17:29:44 --> Could not find the language line "rate"
ERROR - 2016-12-28 17:29:44 --> Could not find the language line "long_description"
ERROR - 2016-12-28 17:29:44 --> Could not find the language line "address"
ERROR - 2016-12-28 17:29:44 --> Could not find the language line "status"
ERROR - 2016-12-28 17:29:44 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 17:29:44 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 17:29:44 --> Could not find the language line "banios"
ERROR - 2016-12-28 17:29:44 --> Could not find the language line "precio"
ERROR - 2016-12-28 17:38:50 --> Could not find the language line "description"
ERROR - 2016-12-28 17:38:50 --> Could not find the language line "rate"
ERROR - 2016-12-28 17:38:50 --> Could not find the language line "long_description"
ERROR - 2016-12-28 17:38:50 --> Could not find the language line "address"
ERROR - 2016-12-28 17:38:50 --> Could not find the language line "status"
ERROR - 2016-12-28 17:38:50 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 17:38:50 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 17:38:50 --> Could not find the language line "banios"
ERROR - 2016-12-28 17:38:50 --> Could not find the language line "precio"
ERROR - 2016-12-28 17:52:28 --> Could not find the language line "description"
ERROR - 2016-12-28 17:52:28 --> Could not find the language line "rate"
ERROR - 2016-12-28 17:52:28 --> Could not find the language line "long_description"
ERROR - 2016-12-28 17:52:28 --> Could not find the language line "address"
ERROR - 2016-12-28 17:52:28 --> Could not find the language line "status"
ERROR - 2016-12-28 17:52:28 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 17:52:28 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 17:52:28 --> Could not find the language line "banios"
ERROR - 2016-12-28 17:52:28 --> Could not find the language line "precio"
ERROR - 2016-12-28 17:53:14 --> Could not find the language line "description"
ERROR - 2016-12-28 17:53:14 --> Could not find the language line "rate"
ERROR - 2016-12-28 17:53:14 --> Could not find the language line "long_description"
ERROR - 2016-12-28 17:53:14 --> Could not find the language line "address"
ERROR - 2016-12-28 17:53:14 --> Could not find the language line "status"
ERROR - 2016-12-28 17:53:14 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 17:53:14 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 17:53:14 --> Could not find the language line "banios"
ERROR - 2016-12-28 17:53:14 --> Could not find the language line "precio"
ERROR - 2016-12-28 18:28:57 --> Could not find the language line "description"
ERROR - 2016-12-28 18:28:57 --> Could not find the language line "rate"
ERROR - 2016-12-28 18:28:57 --> Could not find the language line "long_description"
ERROR - 2016-12-28 18:28:57 --> Could not find the language line "address"
ERROR - 2016-12-28 18:28:57 --> Could not find the language line "status"
ERROR - 2016-12-28 18:28:57 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 18:28:57 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 18:28:57 --> Could not find the language line "banios"
ERROR - 2016-12-28 18:28:57 --> Could not find the language line "precio"
ERROR - 2016-12-28 18:34:35 --> Could not find the language line "description"
ERROR - 2016-12-28 18:34:35 --> Could not find the language line "rate"
ERROR - 2016-12-28 18:34:35 --> Could not find the language line "long_description"
ERROR - 2016-12-28 18:34:35 --> Could not find the language line "address"
ERROR - 2016-12-28 18:34:35 --> Could not find the language line "status"
ERROR - 2016-12-28 18:34:35 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 18:34:35 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 18:34:35 --> Could not find the language line "banios"
ERROR - 2016-12-28 18:34:35 --> Could not find the language line "precio"
ERROR - 2016-12-28 18:40:39 --> Could not find the language line "description"
ERROR - 2016-12-28 18:40:39 --> Could not find the language line "rate"
ERROR - 2016-12-28 18:40:39 --> Could not find the language line "long_description"
ERROR - 2016-12-28 18:40:39 --> Could not find the language line "address"
ERROR - 2016-12-28 18:40:39 --> Could not find the language line "status"
ERROR - 2016-12-28 18:40:39 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 18:40:39 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 18:40:39 --> Could not find the language line "banios"
ERROR - 2016-12-28 18:40:39 --> Could not find the language line "precio"
ERROR - 2016-12-28 18:43:12 --> Severity: Notice --> Undefined index: id F:\xampp\htdocs\perfex_crm\crm\application\controllers\admin\Invoice_items.php 150
ERROR - 2016-12-28 18:43:12 --> Query error: Unknown column 'item_id' in 'field list' - Invalid query: INSERT INTO `tblunities` (`item_id`, `status`, `m2_habitables`, `recamaras`, `banios`, `precio`) VALUES ('1', '1', '244', '5', '3', '200000')
ERROR - 2016-12-28 18:47:37 --> Severity: Notice --> Undefined index: id F:\xampp\htdocs\perfex_crm\crm\application\controllers\admin\Invoice_items.php 150
ERROR - 2016-12-28 18:47:37 --> Query error: Unknown column 'item_id' in 'field list' - Invalid query: INSERT INTO `tblunities` (`item_id`, `status`, `m2_habitables`, `recamaras`, `banios`, `precio`) VALUES ('1', '1', '244', '5', '3', '200000')
ERROR - 2016-12-28 18:56:56 --> Could not find the language line "description"
ERROR - 2016-12-28 18:56:56 --> Could not find the language line "rate"
ERROR - 2016-12-28 18:56:56 --> Could not find the language line "long_description"
ERROR - 2016-12-28 18:56:56 --> Could not find the language line "address"
ERROR - 2016-12-28 18:56:56 --> Could not find the language line "status"
ERROR - 2016-12-28 18:56:56 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 18:56:56 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 18:56:56 --> Could not find the language line "banios"
ERROR - 2016-12-28 18:56:56 --> Could not find the language line "precio"
ERROR - 2016-12-28 18:59:17 --> Severity: Notice --> Undefined index: id F:\xampp\htdocs\perfex_crm\crm\application\controllers\admin\Invoice_items.php 150
ERROR - 2016-12-28 18:59:17 --> Query error: Unknown column 'unity_id' in 'field list' - Invalid query: INSERT INTO `tblunities` (`id_item`, `unity_id`, `status`, `m2_habitables`, `recamaras`, `banios`, `precio`) VALUES ('1', '', '1', '400', '5', '3', '200000')
ERROR - 2016-12-28 18:59:32 --> Severity: Notice --> Undefined index: id F:\xampp\htdocs\perfex_crm\crm\application\controllers\admin\Invoice_items.php 150
ERROR - 2016-12-28 18:59:32 --> Query error: Unknown column 'unity_id' in 'field list' - Invalid query: INSERT INTO `tblunities` (`id_item`, `unity_id`, `status`, `m2_habitables`, `recamaras`, `banios`, `precio`) VALUES ('1', '', '1', '400', '5', '3', '200000')
ERROR - 2016-12-28 19:01:04 --> Could not find the language line "description"
ERROR - 2016-12-28 19:01:04 --> Could not find the language line "rate"
ERROR - 2016-12-28 19:01:04 --> Could not find the language line "long_description"
ERROR - 2016-12-28 19:01:04 --> Could not find the language line "address"
ERROR - 2016-12-28 19:01:04 --> Could not find the language line "status"
ERROR - 2016-12-28 19:01:04 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 19:01:04 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 19:01:04 --> Could not find the language line "banios"
ERROR - 2016-12-28 19:01:04 --> Could not find the language line "precio"
ERROR - 2016-12-28 19:21:33 --> Could not find the language line "description"
ERROR - 2016-12-28 19:21:33 --> Could not find the language line "rate"
ERROR - 2016-12-28 19:21:33 --> Could not find the language line "long_description"
ERROR - 2016-12-28 19:21:33 --> Could not find the language line "address"
ERROR - 2016-12-28 19:21:33 --> Could not find the language line "status"
ERROR - 2016-12-28 19:21:33 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 19:21:33 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 19:21:33 --> Could not find the language line "banios"
ERROR - 2016-12-28 19:21:33 --> Could not find the language line "precio"
ERROR - 2016-12-28 19:35:34 --> Could not find the language line "description"
ERROR - 2016-12-28 19:35:34 --> Could not find the language line "rate"
ERROR - 2016-12-28 19:35:34 --> Could not find the language line "long_description"
ERROR - 2016-12-28 19:35:34 --> Could not find the language line "address"
ERROR - 2016-12-28 19:35:34 --> Could not find the language line "status"
ERROR - 2016-12-28 19:35:34 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 19:35:34 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 19:35:34 --> Could not find the language line "banios"
ERROR - 2016-12-28 19:35:34 --> Could not find the language line "precio"
ERROR - 2016-12-28 19:36:23 --> Severity: Notice --> Undefined variable: id F:\xampp\htdocs\perfex_crm\crm\application\controllers\admin\Invoice_items.php 183
ERROR - 2016-12-28 19:39:13 --> Severity: Notice --> Undefined variable: id F:\xampp\htdocs\perfex_crm\crm\application\controllers\admin\Invoice_items.php 183
ERROR - 2016-12-28 19:41:55 --> Could not find the language line "description"
ERROR - 2016-12-28 19:41:55 --> Could not find the language line "rate"
ERROR - 2016-12-28 19:41:55 --> Could not find the language line "long_description"
ERROR - 2016-12-28 19:41:55 --> Could not find the language line "address"
ERROR - 2016-12-28 19:41:55 --> Could not find the language line "status"
ERROR - 2016-12-28 19:41:55 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 19:41:55 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 19:41:55 --> Could not find the language line "banios"
ERROR - 2016-12-28 19:41:55 --> Could not find the language line "precio"
ERROR - 2016-12-28 19:51:43 --> Could not find the language line "description"
ERROR - 2016-12-28 19:51:43 --> Could not find the language line "rate"
ERROR - 2016-12-28 19:51:43 --> Could not find the language line "long_description"
ERROR - 2016-12-28 19:51:43 --> Could not find the language line "address"
ERROR - 2016-12-28 19:51:43 --> Could not find the language line "status"
ERROR - 2016-12-28 19:51:43 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 19:51:43 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 19:51:43 --> Could not find the language line "banios"
ERROR - 2016-12-28 19:51:43 --> Could not find the language line "precio"
ERROR - 2016-12-28 19:54:58 --> Could not find the language line "description"
ERROR - 2016-12-28 19:54:58 --> Could not find the language line "rate"
ERROR - 2016-12-28 19:54:58 --> Could not find the language line "long_description"
ERROR - 2016-12-28 19:54:58 --> Could not find the language line "address"
ERROR - 2016-12-28 19:54:58 --> Could not find the language line "status"
ERROR - 2016-12-28 19:54:58 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 19:54:58 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 19:54:58 --> Could not find the language line "banios"
ERROR - 2016-12-28 19:54:58 --> Could not find the language line "precio"
ERROR - 2016-12-28 19:55:57 --> Could not find the language line "description"
ERROR - 2016-12-28 19:55:57 --> Could not find the language line "rate"
ERROR - 2016-12-28 19:55:57 --> Could not find the language line "long_description"
ERROR - 2016-12-28 19:55:57 --> Could not find the language line "address"
ERROR - 2016-12-28 19:55:57 --> Could not find the language line "status"
ERROR - 2016-12-28 19:55:57 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 19:55:57 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 19:55:57 --> Could not find the language line "banios"
ERROR - 2016-12-28 19:55:57 --> Could not find the language line "precio"
ERROR - 2016-12-28 19:59:34 --> Could not find the language line "description"
ERROR - 2016-12-28 19:59:34 --> Could not find the language line "rate"
ERROR - 2016-12-28 19:59:34 --> Could not find the language line "long_description"
ERROR - 2016-12-28 19:59:34 --> Could not find the language line "address"
ERROR - 2016-12-28 19:59:34 --> Could not find the language line "status"
ERROR - 2016-12-28 19:59:34 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 19:59:34 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 19:59:34 --> Could not find the language line "banios"
ERROR - 2016-12-28 19:59:34 --> Could not find the language line "precio"
ERROR - 2016-12-28 20:03:04 --> Could not find the language line "description"
ERROR - 2016-12-28 20:03:04 --> Could not find the language line "rate"
ERROR - 2016-12-28 20:03:04 --> Could not find the language line "long_description"
ERROR - 2016-12-28 20:03:04 --> Could not find the language line "address"
ERROR - 2016-12-28 20:03:04 --> Could not find the language line "status"
ERROR - 2016-12-28 20:03:04 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 20:03:04 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 20:03:04 --> Could not find the language line "banios"
ERROR - 2016-12-28 20:03:04 --> Could not find the language line "precio"
ERROR - 2016-12-28 20:04:05 --> Could not find the language line "description"
ERROR - 2016-12-28 20:04:05 --> Could not find the language line "rate"
ERROR - 2016-12-28 20:04:05 --> Could not find the language line "long_description"
ERROR - 2016-12-28 20:04:05 --> Could not find the language line "address"
ERROR - 2016-12-28 20:04:05 --> Could not find the language line "status"
ERROR - 2016-12-28 20:04:05 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 20:04:05 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 20:04:05 --> Could not find the language line "banios"
ERROR - 2016-12-28 20:04:05 --> Could not find the language line "precio"
ERROR - 2016-12-28 20:05:47 --> Severity: Notice --> Undefined index: tax F:\xampp\htdocs\perfex_crm\crm\application\models\Invoice_items_model.php 34
ERROR - 2016-12-28 20:10:36 --> Could not find the language line "description"
ERROR - 2016-12-28 20:10:36 --> Could not find the language line "rate"
ERROR - 2016-12-28 20:10:36 --> Could not find the language line "long_description"
ERROR - 2016-12-28 20:10:36 --> Could not find the language line "address"
ERROR - 2016-12-28 20:10:36 --> Could not find the language line "status"
ERROR - 2016-12-28 20:10:36 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 20:10:36 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 20:10:36 --> Could not find the language line "banios"
ERROR - 2016-12-28 20:10:36 --> Could not find the language line "precio"
ERROR - 2016-12-28 20:12:00 --> Could not find the language line "description"
ERROR - 2016-12-28 20:12:00 --> Could not find the language line "rate"
ERROR - 2016-12-28 20:12:00 --> Could not find the language line "long_description"
ERROR - 2016-12-28 20:12:00 --> Could not find the language line "address"
ERROR - 2016-12-28 20:12:00 --> Could not find the language line "status"
ERROR - 2016-12-28 20:12:00 --> Could not find the language line "m2_habitables"
ERROR - 2016-12-28 20:12:00 --> Could not find the language line "recamaras"
ERROR - 2016-12-28 20:12:00 --> Could not find the language line "banios"
ERROR - 2016-12-28 20:12:00 --> Could not find the language line "precio"
