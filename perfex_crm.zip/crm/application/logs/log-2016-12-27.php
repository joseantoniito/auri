<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-27 03:18:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 03:18:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 03:18:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 03:19:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 03:26:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 03:26:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 03:26:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 03:26:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 03:26:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 03:26:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 03:27:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 03:27:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 03:27:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 03:29:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 03:29:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 03:29:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 03:42:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 03:42:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 03:42:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 03:51:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 03:51:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 03:51:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 03:59:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 03:59:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 03:59:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 04:00:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 04:00:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 04:00:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 04:01:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 04:01:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 04:01:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 04:10:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 04:10:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 04:10:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 04:42:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 04:42:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 04:42:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 04:43:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 04:43:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 04:43:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 04:47:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 04:47:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 04:47:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 04:48:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 04:48:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 04:48:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 04:54:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 04:54:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 04:54:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 05:04:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 05:04:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 05:04:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-27 07:57:26 --> 404 Page Not Found: admin/Invoice_items/invoice_item
ERROR - 2016-12-27 01:12:10 --> Could not find the language line "Qualification"
ERROR - 2016-12-27 01:12:13 --> Could not find the language line "Qualification"
ERROR - 2016-12-27 01:13:09 --> Could not find the language line "Qualification"
ERROR - 2016-12-27 01:13:17 --> Could not find the language line "Qualification"
ERROR - 2016-12-27 01:13:24 --> Could not find the language line "Qualification"
ERROR - 2016-12-27 01:13:34 --> Could not find the language line "Qualification"
ERROR - 2016-12-27 01:13:39 --> Could not find the language line "Qualification"
ERROR - 2016-12-27 08:38:08 --> 404 Page Not Found: admin/Knowledge_base/articles
ERROR - 2016-12-27 08:46:52 --> 404 Page Not Found: admin/Invoice_items/invoice-item
ERROR - 2016-12-27 09:00:17 --> 404 Page Not Found: admin/Invoice_items/ivoice-item
ERROR - 2016-12-27 09:00:23 --> 404 Page Not Found: admin/Invoice_items/invoice-item
ERROR - 2016-12-27 09:00:46 --> 404 Page Not Found: admin/Invoice_items/invoice-item
ERROR - 2016-12-27 09:01:27 --> 404 Page Not Found: admin/Invoice_items/invoice_item
ERROR - 2016-12-27 02:04:31 --> Could not find the language line "Qualification"
ERROR - 2016-12-27 02:07:50 --> Could not find the language line "Qualification"
ERROR - 2016-12-27 21:53:34 --> Severity: Notice --> Undefined index: id F:\xampp\htdocs\perfex_crm\crm\application\controllers\admin\Invoice_items.php 143
ERROR - 2016-12-27 21:53:34 --> Query error: Unknown column 'itemid' in 'field list' - Invalid query: INSERT INTO `tblunities` (`itemid`, `status`, `m2_habitables`, `recamaras`, `banios`, `precio`) VALUES ('1', '1', '200', '4', '2', '100000')
ERROR - 2016-12-27 21:56:13 --> Severity: Notice --> Undefined index: id F:\xampp\htdocs\perfex_crm\crm\application\controllers\admin\Invoice_items.php 143
ERROR - 2016-12-27 21:56:13 --> Query error: Unknown column 'itemid' in 'field list' - Invalid query: INSERT INTO `tblunities` (`itemid`, `status`, `m2_habitables`, `recamaras`, `banios`, `precio`) VALUES ('1', '1', '200', '4', '2', '100000')
ERROR - 2016-12-27 22:15:49 --> Severity: Notice --> Undefined index: id F:\xampp\htdocs\perfex_crm\crm\application\controllers\admin\Invoice_items.php 143
ERROR - 2016-12-27 22:15:49 --> Query error: Unknown column 'itemid' in 'field list' - Invalid query: INSERT INTO `tblunities` (`itemid`, `status`, `m2_habitables`, `recamaras`, `banios`, `precio`) VALUES ('1', '1', '200', '4', '2', '100000')
ERROR - 2016-12-27 22:20:44 --> Severity: Notice --> Undefined index: tax F:\xampp\htdocs\perfex_crm\crm\application\models\Invoice_items_model.php 34
ERROR - 2016-12-27 22:21:06 --> Severity: Notice --> Undefined index: tax F:\xampp\htdocs\perfex_crm\crm\application\models\Invoice_items_model.php 34
ERROR - 2016-12-27 22:23:03 --> Severity: Notice --> Undefined index: id F:\xampp\htdocs\perfex_crm\crm\application\controllers\admin\Invoice_items.php 143
ERROR - 2016-12-27 22:23:03 --> Query error: Unknown column 'itemid' in 'field list' - Invalid query: INSERT INTO `tblunities` (`itemid`, `status`, `m2_habitables`, `recamaras`, `banios`, `precio`) VALUES ('1', '1', '200', '4', '2', '100000')
ERROR - 2016-12-27 22:23:55 --> Severity: Notice --> Undefined index: id F:\xampp\htdocs\perfex_crm\crm\application\controllers\admin\Invoice_items.php 143
ERROR - 2016-12-27 22:35:56 --> Query error: Table 'tblformquestionboxes' is marked as crashed and should be repaired - Invalid query: SELECT *
FROM `tblformquestionboxes`
WHERE `questionid` = '1'
ERROR - 2016-12-27 22:36:17 --> Query error: Table 'tblformquestionboxes' is marked as crashed and should be repaired - Invalid query: SELECT *
FROM `tblformquestionboxes`
WHERE `questionid` = '1'
