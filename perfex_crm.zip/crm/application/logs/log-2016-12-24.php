<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-24 02:24:38 --> 404 Page Not Found: admin/Login/index
ERROR - 2016-12-24 02:27:56 --> 404 Page Not Found: admin/Login/index
ERROR - 2016-12-24 02:37:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'auri_perfex'@'localhost' (using password: YES) F:\xampp\htdocs\perfex_crm\crm\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2016-12-24 02:37:52 --> Unable to connect to the database
ERROR - 2016-12-24 02:41:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'auri_perfex'@'localhost' (using password: YES) F:\xampp\htdocs\perfex_crm\crm\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2016-12-24 02:41:28 --> Unable to connect to the database
ERROR - 2016-12-24 02:41:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'auri_perfex'@'localhost' (using password: YES) F:\xampp\htdocs\perfex_crm\crm\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2016-12-24 02:41:59 --> Unable to connect to the database
ERROR - 2016-12-24 02:44:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'auri_perfex'@'localhost' (using password: YES) F:\xampp\htdocs\perfex_crm\crm\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2016-12-24 02:44:23 --> Unable to connect to the database
ERROR - 2016-12-24 02:45:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'auri_perfex'@'localhost' (using password: YES) F:\xampp\htdocs\perfex_crm\crm\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2016-12-24 02:45:11 --> Unable to connect to the database
ERROR - 2016-12-24 07:12:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-24 07:12:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-24 07:12:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-24 07:44:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-24 07:44:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-24 07:44:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-24 08:55:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-24 08:55:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-24 08:55:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-24 09:04:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-24 09:04:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-24 09:04:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-24 09:04:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-24 09:04:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-24 09:04:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-24 09:55:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-24 09:55:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-24 09:55:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-24 10:17:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-24 10:17:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-12-24 10:17:29 --> 404 Page Not Found: Assets/plugins
