<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-26 15:48:13 --> Query error: Table 'tblticketstatus' is marked as crashed and should be repaired - Invalid query: SELECT *
FROM `tblticketstatus`
ORDER BY `statusorder` ASC
ERROR - 2016-12-26 16:24:19 --> Query error: Table 'tblactivitylog' is marked as crashed and should be repaired - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS description, date, `tblactivitylog`.`staffid` AS `tblactivitylog.staffid` 
    FROM   tblactivitylog
    
    
    
    ORDER BY  date DESC
    
    LIMIT 0, 25
    
ERROR - 2016-12-26 16:34:48 --> Query error: Incorrect key file for table '.\auri_perfex_crm\tblactivitylog.MYI'; try to repair it - Invalid query: INSERT INTO `tblactivitylog` (`description`, `date`, `staffid`) VALUES ('New Client Created [dummy From Staff: 1]', '2016-12-26 16:34:48', ' ')
ERROR - 2016-12-26 18:17:06 --> Could not find the language line "Qualification"
ERROR - 2016-12-26 18:19:14 --> Could not find the language line "Qualification"
ERROR - 2016-12-26 18:22:03 --> Could not find the language line "Qualification"
ERROR - 2016-12-26 20:17:40 --> Severity: Notice --> Undefined offset: 5 F:\xampp\htdocs\perfex_crm\crm\application\helpers\perfex_db_helper.php 660
ERROR - 2016-12-26 20:26:15 --> Severity: Notice --> Undefined offset: 5 F:\xampp\htdocs\perfex_crm\crm\application\helpers\perfex_db_helper.php 660
ERROR - 2016-12-26 20:26:15 --> Severity: Notice --> Undefined index: tblitems.name as item_name F:\xampp\htdocs\perfex_crm\crm\application\views\admin\tables\invoice_items.php 30
ERROR - 2016-12-26 20:26:33 --> Severity: Notice --> Undefined offset: 5 F:\xampp\htdocs\perfex_crm\crm\application\helpers\perfex_db_helper.php 660
ERROR - 2016-12-26 20:26:33 --> Severity: Notice --> Undefined index: tblitems.name as item_name F:\xampp\htdocs\perfex_crm\crm\application\views\admin\tables\invoice_items.php 30
ERROR - 2016-12-26 22:10:50 --> Could not find the language line "CC"
ERROR - 2016-12-26 22:11:25 --> Could not find the language line "CC"
