<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-23 19:24:28 --> Severity: Notice --> Trying to get property of non-object F:\xampp\htdocs\perfex_crm\crm\application\models\Misc_model.php 117
ERROR - 2016-12-23 19:24:28 --> Severity: Notice --> Trying to get property of non-object F:\xampp\htdocs\perfex_crm\crm\application\models\Misc_model.php 117
ERROR - 2016-12-23 19:29:48 --> Severity: Notice --> Trying to get property of non-object F:\xampp\htdocs\perfex_crm\crm\application\models\Misc_model.php 117
ERROR - 2016-12-23 19:29:48 --> Severity: Notice --> Trying to get property of non-object F:\xampp\htdocs\perfex_crm\crm\application\models\Misc_model.php 117
ERROR - 2016-12-23 19:30:18 --> Severity: Notice --> Trying to get property of non-object F:\xampp\htdocs\perfex_crm\crm\application\models\Misc_model.php 117
ERROR - 2016-12-23 19:30:18 --> Severity: Notice --> Trying to get property of non-object F:\xampp\htdocs\perfex_crm\crm\application\models\Misc_model.php 117
ERROR - 2016-12-23 19:30:19 --> Query error: Duplicate column name 'leadid' - Invalid query: ALTER TABLE `tblclients`
	ADD `leadid` INT NULL DEFAULT NULL
ERROR - 2016-12-23 19:30:41 --> Severity: Notice --> Trying to get property of non-object F:\xampp\htdocs\perfex_crm\crm\application\models\Misc_model.php 117
ERROR - 2016-12-23 19:30:41 --> Severity: Notice --> Trying to get property of non-object F:\xampp\htdocs\perfex_crm\crm\application\models\Misc_model.php 117
ERROR - 2016-12-23 19:31:01 --> Severity: Notice --> Trying to get property of non-object F:\xampp\htdocs\perfex_crm\crm\application\models\Misc_model.php 117
ERROR - 2016-12-23 19:31:01 --> Severity: Notice --> Trying to get property of non-object F:\xampp\htdocs\perfex_crm\crm\application\models\Misc_model.php 117
ERROR - 2016-12-23 19:31:01 --> Query error: Duplicate column name 'leadid' - Invalid query: ALTER TABLE `tblclients`
	ADD `leadid` INT NULL DEFAULT NULL
